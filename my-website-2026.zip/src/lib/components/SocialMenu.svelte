<script>
  import { siteConfig } from '$lib/config'
</script>

<nav class="space-y-3">
  <h3 class="text-sm font-bold tracking-wider text-gray-950 uppercase dark:text-gray-50">
    Kết nối với mình
  </h3>
  <ul class="flex list-none flex-wrap gap-4">
    {#if siteConfig.social.facebook && siteConfig.social.facebook !== '/'}
      <li>
        <a
          href={siteConfig.social.facebook}
          class="inline-flex h-12 w-12 items-center justify-center text-gray-950 transition-colors duration-300 hover:text-sky-800 dark:text-gray-50 dark:hover:text-sky-400"
          aria-label="Facebook"
          target="_blank"
          rel="noopener noreferrer"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
            aria-hidden="true"
            ><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-4h3l1-4h-4V7a1 1 0 0 1 1-1h3z"
            ></path></svg
          >
        </a>
      </li>
    {/if}
    {#if siteConfig.social.github && siteConfig.social.github !== '/'}
      <li>
        <a
          href={siteConfig.social.github}
          class="inline-flex h-12 w-12 items-center justify-center text-gray-950 transition-colors duration-300 hover:text-gray-900 dark:text-gray-50 dark:hover:text-white"
          aria-label="GitHub"
          target="_blank"
          rel="noopener noreferrer"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
            aria-hidden="true"
            ><path
              d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.71c0 5.42 3.3 6.61 6.44 7a3.37 3.37 0 0 0-.94 2.58V22"
            ></path></svg
          >
        </a>
      </li>
    {/if}
  </ul>
</nav>
