---
title: Liên hệ
menu: 'nav'
---

# Kết nối với mình nhé! ☕

Cảm ơn anh em đã có nhã ý muốn ghé lại đây lâu hơn một chút để kết nối với mình.

Dù là anh em muốn góp ý bài viết, bàn chuyện hợp tác, hay đơn giản là tìm một người cùng ngành để "xả" bớt mấy cái **bug** cuộc sống, mình luôn sẵn lòng lắng nghe. Mình không hứa là sẽ trả lời nhanh như cách CPU xử lý logic, nhưng chắc chắn mọi tin nhắn chân thành từ anh em, mình đều trân trọng.

Có một vài lưu ý nhỏ trước khi anh em "ping" mình:

- **Đi thẳng vào vấn đề:** Mình là dân kỹ thuật mà, cứ thoải mái và thật thà là mình quý nhất. Đừng ngần ngại "phun" luôn requirement ra nhé!
- **Chờ mình một chút:** Đôi khi mình bị deadline dí sấp mặt hoặc đang bận "debug" đời mình, nên nếu thấy phản hồi hơi chậm thì anh em đừng giận nhé. Mình sẽ trả lời ngay khi máy hết "treo" (hang).

Anh em có thể gửi email trực tiếp tới:

📧 **contact@codingnguyen.dev**

Hoặc đơn giản hơn là điền nhanh vào cái biểu mẫu ngay phía dưới này. Anh em nhớ điền kỹ mấy chỗ có đánh dấu sao (**\***) thì hệ thống mới cho phép **submit** nhé.

**Rất mong nhận được tín hiệu (signal) từ anh em!** 🤘

---
