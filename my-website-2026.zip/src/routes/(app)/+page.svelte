<script>
  import PageContent from '$lib/components/PageContent.svelte'
  import PostsList from '$lib/components/PostsList.svelte'
  import SEO from '$lib/components/SEO.svelte'
  import { siteConfig } from '$lib/config'
  import { serializeSchema } from '$lib/utils/seo'

  let { data } = $props()

  // Logic: Just use posts from data. Home posts are fetched at build time (static)
  const latestPosts = $derived(data?.latestPosts || [])

  // SEO Config
  const seoTitle = $derived(data.metadata?.title || siteConfig.title)
  const seoDescription = $derived(data.metadata?.description || siteConfig.description)

  // Structured Data (JSON-LD)
  const websiteSchema = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: siteConfig.title,
    description: siteConfig.description,
    url: siteConfig.siteUrl,
    author: {
      '@type': 'Person',
      name: siteConfig.author.name
    }
  }
</script>

<SEO
  title={seoTitle}
  description={seoDescription}
  canonical={siteConfig.siteUrl}
  openGraph={{
    type: 'website',
    title: seoTitle,
    description: seoDescription,
    site_name: siteConfig.title
  }}
/>

<svelte:head>
  <!-- eslint-disable-next-line svelte/no-at-html-tags -->
  {@html serializeSchema(websiteSchema)}
</svelte:head>

<div class="space-y-16">
  <!-- Personal Intro Section (Hero) - Clean & Focused -->
  <section class="border-b border-gray-100 py-12 dark:border-gray-800">
    <div class="max-w-none">
      <PageContent {data} />
    </div>
  </section>

  <!-- Latest Section - Simple List -->
  {#if latestPosts.length > 0}
    <section class="space-y-12">
      <div class="flex items-center gap-4">
        <h2 class="text-xs font-black tracking-[0.3em] text-gray-950 dark:text-gray-50">
          bài viết mới
        </h2>
        <div class="h-px flex-grow bg-gray-100 dark:bg-gray-800"></div>
      </div>
      <PostsList posts={latestPosts} />

      <div class="pt-8">
        <a
          href="/blog"
          data-sveltekit-preload-data="hover"
          class="inline-flex rounded-full bg-gray-950 px-8 py-4 text-sm font-black text-white shadow-xl transition-transform hover:scale-105 dark:bg-white dark:text-gray-950"
        >
          Xem tất cả bài viết
        </a>
      </div>
    </section>
  {/if}
</div>
