export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	app_dir: "_app",
	app_path: "_app",
	assets: new Set(["ads.txt","apple-touch-icon.png","background.svg","favicon.svg","logo.svg","manifest.json","maskable-512x512.png","og-image.jpg","pwa-192x192.png","pwa-512x512.png","robots.txt","service-worker.js"]),
	mime_types: {".txt":"text/plain",".png":"image/png",".svg":"image/svg+xml",".json":"application/json",".jpg":"image/jpeg",".xml":"text/xml"},
	client: {start:"_app/immutable/entry/start.YjuF2EC7.js",app:"_app/immutable/entry/app.CVp-LFeR.js",imports:["_app/immutable/entry/start.YjuF2EC7.js","_app/immutable/entry/payload.DSmR2FwN.js","_app/immutable/chunks/C4bZyhhW.js","_app/immutable/chunks/Bz3Er71X.js","_app/immutable/chunks/DeyBZs3Z.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/MQdrFSmi.js","_app/immutable/chunks/BwvFoaXl.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/FSyWHmTG.js","_app/immutable/chunks/CreqxSBQ.js","_app/immutable/chunks/LJpiHYKR.js","_app/immutable/chunks/DYrviY11.js","_app/immutable/entry/app.CVp-LFeR.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
	
	nodes: [
		__memo(() => import('./nodes/0.js')),
		__memo(() => import('./nodes/1.js'))
	],
	remotes: {
		
	},
	routes: [
		
	],
	prerendered_routes: new Set(["/","/__data.json","/admin","/admin/__data.json","/blog","/blog/__data.json","/blog/category","/blog/category/__data.json","/blog/tag","/blog/tag/__data.json","/contact","/contact/__data.json","/rss.xml","/sitemap.xml","/blog/category/cong-nghe","/blog/category/cong-nghe/__data.json","/blog/category/nghe-nghiep","/blog/category/nghe-nghiep/__data.json","/blog/tag/ai","/blog/tag/ai/__data.json","/blog/tag/lap-trinh","/blog/tag/lap-trinh/__data.json","/blog/tag/tuong-lai","/blog/tag/tuong-lai/__data.json","/blog/tuong-lai-nao-cho-nganh-lap-trinh-2025-1","/blog/tuong-lai-nao-cho-nganh-lap-trinh-2025-1/__data.json","/blog/tuong-lai-nao-cho-nganh-lap-trinh-2025","/blog/tuong-lai-nao-cho-nganh-lap-trinh-2025/__data.json","/privacy-policy","/privacy-policy/__data.json","/about","/about/__data.json","/accessibility-statement","/accessibility-statement/__data.json"]),
	matchers: async () => {
		return {};
	},
	server_assets: {}
}
})();
