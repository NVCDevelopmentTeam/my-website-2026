export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	app_dir: "_app",
	app_path: "_app",
	assets: new Set(["ads.txt","apple-touch-icon.png","background.svg","favicon.svg","logo.svg","manifest.json","maskable-512x512.png","og-image.jpg","pwa-192x192.png","pwa-512x512.png","robots.txt","service-worker.js"]),
	mime_types: {".txt":"text/plain",".png":"image/png",".svg":"image/svg+xml",".json":"application/json",".jpg":"image/jpeg"},
	client: {start:"_app/immutable/entry/start.YjuF2EC7.js",app:"_app/immutable/entry/app.CVp-LFeR.js",imports:["_app/immutable/entry/start.YjuF2EC7.js","_app/immutable/entry/payload.DSmR2FwN.js","_app/immutable/chunks/C4bZyhhW.js","_app/immutable/chunks/Bz3Er71X.js","_app/immutable/chunks/DeyBZs3Z.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/MQdrFSmi.js","_app/immutable/chunks/BwvFoaXl.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/FSyWHmTG.js","_app/immutable/chunks/CreqxSBQ.js","_app/immutable/chunks/LJpiHYKR.js","_app/immutable/chunks/DYrviY11.js","_app/immutable/entry/app.CVp-LFeR.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
	
	nodes: [
		__memo(() => import('./nodes/0.js')),
		__memo(() => import('./nodes/1.js')),
		__memo(() => import('./nodes/2.js')),
		__memo(() => import('./nodes/3.js')),
		__memo(() => import('./nodes/4.js')),
		__memo(() => import('./nodes/5.js')),
		__memo(() => import('./nodes/6.js')),
		__memo(() => import('./nodes/7.js')),
		__memo(() => import('./nodes/8.js')),
		__memo(() => import('./nodes/9.js')),
		__memo(() => import('./nodes/10.js')),
		__memo(() => import('./nodes/11.js')),
		__memo(() => import('./nodes/12.js')),
		__memo(() => import('./nodes/13.js')),
		__memo(() => import('./nodes/14.js'))
	],
	remotes: {
		
	},
	routes: [
		{
			id: "/(app)",
			pattern: /^\/$/,
			params: [],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 5 },
			endpoint: null
		},
		{
			id: "/admin",
			pattern: /^\/admin\/?$/,
			params: [],
			page: { layouts: [0,4,], errors: [1,,], leaf: 14 },
			endpoint: null
		},
		{
			id: "/(app)/blog",
			pattern: /^\/blog\/?$/,
			params: [],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 7 },
			endpoint: null
		},
		{
			id: "/(app)/blog/category",
			pattern: /^\/blog\/category\/?$/,
			params: [],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 9 },
			endpoint: null
		},
		{
			id: "/(app)/blog/category/[category]",
			pattern: /^\/blog\/category\/([^/]+?)\/?$/,
			params: [{"name":"category","optional":false,"rest":false,"chained":false}],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 10 },
			endpoint: null
		},
		{
			id: "/(app)/blog/tag",
			pattern: /^\/blog\/tag\/?$/,
			params: [],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 11 },
			endpoint: null
		},
		{
			id: "/(app)/blog/tag/[tag]",
			pattern: /^\/blog\/tag\/([^/]+?)\/?$/,
			params: [{"name":"tag","optional":false,"rest":false,"chained":false}],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 12 },
			endpoint: null
		},
		{
			id: "/(app)/blog/[post]",
			pattern: /^\/blog\/([^/]+?)\/?$/,
			params: [{"name":"post","optional":false,"rest":false,"chained":false}],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 8 },
			endpoint: null
		},
		{
			id: "/(app)/contact",
			pattern: /^\/contact\/?$/,
			params: [],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 13 },
			endpoint: null
		},
		{
			id: "/(app)/rss.xml",
			pattern: /^\/rss\.xml\/?$/,
			params: [],
			page: null,
			endpoint: __memo(() => import('./entries/endpoints/(app)/rss.xml/_server.js'))
		},
		{
			id: "/(app)/sitemap.xml",
			pattern: /^\/sitemap\.xml\/?$/,
			params: [],
			page: null,
			endpoint: __memo(() => import('./entries/endpoints/(app)/sitemap.xml/_server.js'))
		},
		{
			id: "/(app)/[page]",
			pattern: /^\/([^/]+?)\/?$/,
			params: [{"name":"page","optional":false,"rest":false,"chained":false}],
			page: { layouts: [0,2,], errors: [1,3,], leaf: 6 },
			endpoint: null
		}
	],
	prerendered_routes: new Set([]),
	matchers: async () => {
		return {};
	},
	server_assets: {}
}
})();
