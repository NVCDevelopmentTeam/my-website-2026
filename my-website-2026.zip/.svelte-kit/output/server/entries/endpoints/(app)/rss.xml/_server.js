import{t as e}from"../../../../chunks/config.js";import{r as t}from"../../../../chunks/posts.js";import{t as n}from"../../../../chunks/escapeXml.js";var r=!0,i=`never`;async function a({setHeaders:r}){r({"Cache-Control":`max-age=0, s-maxage=3600`,"Content-Type":`application/xml; charset=utf-8`});try{let{posts:r=[]}=await t({limit:-1})||{},i=r.map(t=>{var r,i,a,o,s,c,l;let u=`${e.siteUrl}/blog/${t.slug}`,d=(r=t.metadata)!=null&&r.date?new Date(t.metadata.date).toUTCString():new Date().toUTCString();return`
    <item>
      <guid isPermaLink="true">${u}</guid>
      <title>${n(((i=t.metadata)==null?void 0:i.title)||`Untitled`)}</title>
      <link>${u}</link>
      <description>${n(((a=t.metadata)==null?void 0:a.description)||((o=t.metadata)==null?void 0:o.excerpt)||`No description available`)}</description>
      <pubDate>${d}</pubDate>
      <author>${n(((s=t.metadata)==null?void 0:s.author)||((c=e.author)==null?void 0:c.name)||e.title)}</author>
      ${Array.isArray((l=t.metadata)==null?void 0:l.categories)?t.metadata.categories.map(e=>`<category>${n(e)}</category>`).join(`
      `):``}
    </item>`}).join(``),a=`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" 
     xmlns:atom="http://www.w3.org/2005/Atom"
     xmlns:dc="http://purl.org/dc/elements/1.1/"
     xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>${n(e.title)}</title>
    <link>${e.siteUrl}</link>
    <description>${n(e.description)}</description>
    <language>${e.language||`vi`}</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <atom:link href="${e.siteUrl}/rss.xml" rel="self" type="application/rss+xml" />
    ${i}
  </channel>
</rss>`;return new Response(a.trim())}catch(t){console.error(`RSS generation error:`,t);let r=`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>${n(e.title)}</title>
    <link>${e.siteUrl}</link>
    <description>${n(e.description)}</description>
  </channel>
</rss>`;return new Response(r.trim())}}export{a as GET,r as prerender,i as trailingSlash};