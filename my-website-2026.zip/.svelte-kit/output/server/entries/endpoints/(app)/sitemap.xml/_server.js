import{t as e}from"../../../../chunks/config.js";import{n as t,r as n,t as r}from"../../../../chunks/posts.js";import{t as i}from"../../../../chunks/escapeXml.js";import{t as a}from"../../../../chunks/pages2.js";var o=!0,s=`never`;async function c({setHeaders:o}){o({"Cache-Control":`max-age=0, s-maxage=3600`,"Content-Type":`application/xml; charset=utf-8`});try{let{pages:o=[]}=await a({limit:-1})||{},{posts:s=[]}=await n({limit:-1})||{},c=await r()||[],l=await t()||[],u=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${`
  <url>
    <loc>${e.siteUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`}${o.filter(e=>e.slug!==`index`).map(t=>`
  <url>
    <loc>${i(`${e.siteUrl}/${t.slug}`)}</loc>
    <changefreq>monthly</changefreq>
    <priority>${t.priority||.7}</priority>
  </url>`).join(``)}${s.map(t=>{var n;let r=(n=t.metadata)!=null&&n.date?new Date(t.metadata.date).toISOString():new Date().toISOString();return`
  <url>
    <loc>${i(`${e.siteUrl}/blog/${t.slug}`)}</loc>
    <lastmod>${r}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>`}).join(``)}${c.map(t=>`
  <url>
    <loc>${i(`${e.siteUrl}/blog/category/${t.metadata.slug}`)}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.5</priority>
  </url>`).join(``)}${l.map(t=>`
  <url>
    <loc>${i(`${e.siteUrl}/blog/tag/${t.slug}`)}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.4</priority>
  </url>`).join(``)}
</urlset>`;return new Response(u.trim())}catch(t){console.error(`Sitemap generation error:`,t);let n=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${e.siteUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>`;return new Response(n.trim())}}export{c as GET,o as prerender,s as trailingSlash};