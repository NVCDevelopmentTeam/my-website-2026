import stylesheet_0 from '../stylesheets/3.BKbGfjcW.css.js';

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/_error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.DhPzllPv.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/LOl63BeZ.js","_app/immutable/chunks/DnjGtGBM.js","_app/immutable/chunks/NBnUjR55.js"];
export const stylesheets = ["_app/immutable/assets/3.BKbGfjcW.css"];
export const fonts = [];
export const inline_styles = () => ({
	"_app/immutable/assets/3.BKbGfjcW.css": stylesheet_0
});
