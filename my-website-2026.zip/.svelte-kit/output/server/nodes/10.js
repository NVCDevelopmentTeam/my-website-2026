import * as universal from '../entries/pages/(app)/blog/category/_category_/_page.js';
import stylesheet_0 from '../stylesheets/PostCategories.CSEWGvKP.css.js';
import stylesheet_1 from '../stylesheets/PostsList.PSTQ6XMr.css.js';
import stylesheet_2 from '../stylesheets/Pagination.DDnSN3fs.css.js';
import stylesheet_3 from '../stylesheets/10.BbCr0eP6.css.js';

export const index = 10;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/blog/category/_category_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/(app)/blog/category/[category]/+page.js";
export const imports = ["_app/immutable/nodes/10.mfPjOGIx.js","_app/immutable/chunks/DK3Fl9T5.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/BwvFoaXl.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/C32VdXOE.js","_app/immutable/chunks/NBnUjR55.js","_app/immutable/chunks/Dtet3fvz.js","_app/immutable/chunks/CreqxSBQ.js","_app/immutable/chunks/LJpiHYKR.js","_app/immutable/entry/payload.DSmR2FwN.js","_app/immutable/chunks/DYrviY11.js","_app/immutable/chunks/DDYK2yM7.js","_app/immutable/chunks/LOl63BeZ.js","_app/immutable/chunks/Cve0VYYs.js","_app/immutable/chunks/DnjGtGBM.js","_app/immutable/chunks/B9IByvcG.js","_app/immutable/chunks/k2HTUTnP.js","_app/immutable/chunks/VKGREjQs.js","_app/immutable/chunks/DgPfzmbm.js","_app/immutable/chunks/BcwFTUIg.js","_app/immutable/chunks/C-cj4Kq_.js","_app/immutable/chunks/DNil_Is5.js"];
export const stylesheets = ["_app/immutable/assets/PostCategories.CSEWGvKP.css","_app/immutable/assets/PostsList.PSTQ6XMr.css","_app/immutable/assets/Pagination.DDnSN3fs.css","_app/immutable/assets/10.BbCr0eP6.css"];
export const fonts = [];
export const inline_styles = () => ({
	"_app/immutable/assets/PostCategories.CSEWGvKP.css": stylesheet_0,
	"_app/immutable/assets/PostsList.PSTQ6XMr.css": stylesheet_1,
	"_app/immutable/assets/Pagination.DDnSN3fs.css": stylesheet_2,
	"_app/immutable/assets/10.BbCr0eP6.css": stylesheet_3
});
