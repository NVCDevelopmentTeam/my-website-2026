

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.BT1i1UMj.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/LJpiHYKR.js","_app/immutable/entry/payload.DSmR2FwN.js","_app/immutable/chunks/DYrviY11.js"];
export const stylesheets = [];
export const fonts = [];
