import * as server from '../entries/pages/(app)/blog/tag/_page.server.js';
import stylesheet_0 from '../stylesheets/11.h_WEy4ec.css.js';

export const index = 11;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/blog/tag/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/(app)/blog/tag/+page.server.js";
export const imports = ["_app/immutable/nodes/11.C42OyEm_.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/LOl63BeZ.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/BwvFoaXl.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/C32VdXOE.js","_app/immutable/chunks/NBnUjR55.js","_app/immutable/chunks/DDYK2yM7.js","_app/immutable/chunks/Cve0VYYs.js","_app/immutable/chunks/DnjGtGBM.js"];
export const stylesheets = ["_app/immutable/assets/11.h_WEy4ec.css"];
export const fonts = [];
export const inline_styles = () => ({
	"_app/immutable/assets/11.h_WEy4ec.css": stylesheet_0
});
