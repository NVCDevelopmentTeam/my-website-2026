import * as universal from '../entries/pages/admin/_layout.js';
import stylesheet_0 from '../stylesheets/SkipLink.Dtde9Gt4.css.js';
import stylesheet_1 from '../stylesheets/4.ZO1TVYp-.css.js';

export const index = 4;
export { universal };
export const universal_id = "src/routes/admin/+layout.js";
export const imports = ["_app/immutable/nodes/4.BlKNBEQZ.js","_app/immutable/chunks/DK3Fl9T5.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/LOl63BeZ.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/Cve0VYYs.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/NBnUjR55.js","_app/immutable/chunks/DiDNBWYB.js"];
export const stylesheets = ["_app/immutable/assets/SkipLink.Dtde9Gt4.css","_app/immutable/assets/4.ZO1TVYp-.css"];
export const fonts = [];
export const inline_styles = () => ({
	"_app/immutable/assets/SkipLink.Dtde9Gt4.css": stylesheet_0,
	"_app/immutable/assets/4.ZO1TVYp-.css": stylesheet_1
});
