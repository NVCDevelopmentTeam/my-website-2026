import stylesheet_0 from '../stylesheets/14.9ucl3ZeX.css.js';

export const index = 14;
export const universal = {
  "prerender": true,
  "trailingSlash": "never",
  "csr": true,
  "ssr": false,
  "load": null
};
export const universal_id = "src/routes/admin/+page.js";
export const imports = ["_app/immutable/nodes/14.k_HNpd_A.js","_app/immutable/chunks/DK3Fl9T5.js","_app/immutable/chunks/C4bZyhhW.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/MQdrFSmi.js","_app/immutable/chunks/BwvFoaXl.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/DnjGtGBM.js","_app/immutable/chunks/NBnUjR55.js"];
export const stylesheets = ["_app/immutable/assets/14.9ucl3ZeX.css"];
export const fonts = [];
export const inline_styles = () => ({
	"_app/immutable/assets/14.9ucl3ZeX.css": stylesheet_0
});
