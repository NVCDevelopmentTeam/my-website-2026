import * as universal from '../entries/pages/(app)/_page_/_page.js';
import * as server from '../entries/pages/(app)/_page_/_page.server.js';
import stylesheet_0 from '../stylesheets/FAQ.Dv2Up_TF.css.js';
import stylesheet_1 from '../stylesheets/PageContent.CkXj2MfO.css.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/_page_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/(app)/[page]/+page.js";
export { server };
export const server_id = "src/routes/(app)/[page]/+page.server.js";
export const imports = ["_app/immutable/nodes/6.kkkT4j2Y.js","_app/immutable/chunks/DK3Fl9T5.js","_app/immutable/chunks/CB7EMLX8.js","_app/immutable/chunks/C4bZyhhW.js","_app/immutable/chunks/DeO3r5zm.js","_app/immutable/chunks/BwvFoaXl.js","_app/immutable/chunks/5uBjJovy.js","_app/immutable/chunks/C32VdXOE.js","_app/immutable/chunks/B18LdsPM.js","_app/immutable/chunks/NBnUjR55.js","_app/immutable/chunks/FSyWHmTG.js","_app/immutable/chunks/LJpiHYKR.js","_app/immutable/entry/payload.DSmR2FwN.js","_app/immutable/chunks/DYrviY11.js","_app/immutable/chunks/9wTxNp5Q.js","_app/immutable/chunks/DnjGtGBM.js","_app/immutable/chunks/DDYK2yM7.js","_app/immutable/chunks/LOl63BeZ.js","_app/immutable/chunks/Cve0VYYs.js","_app/immutable/chunks/Dtet3fvz.js","_app/immutable/chunks/CreqxSBQ.js"];
export const stylesheets = ["_app/immutable/assets/FAQ.Dv2Up_TF.css","_app/immutable/assets/PageContent.CkXj2MfO.css"];
export const fonts = [];
export const inline_styles = () => ({
	"_app/immutable/assets/FAQ.Dv2Up_TF.css": stylesheet_0,
	"_app/immutable/assets/PageContent.CkXj2MfO.css": stylesheet_1
});
