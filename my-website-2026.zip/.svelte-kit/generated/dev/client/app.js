export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14')
];

export const server_loads = [0,2];

export const dictionary = {
		"/(app)": [~5,[2],[3]],
		"/admin": [14,[4]],
		"/(app)/blog": [7,[2],[3]],
		"/(app)/blog/category": [~9,[2],[3]],
		"/(app)/blog/category/[category]": [10,[2],[3]],
		"/(app)/blog/tag": [~11,[2],[3]],
		"/(app)/blog/tag/[tag]": [12,[2],[3]],
		"/(app)/blog/[post]": [~8,[2],[3]],
		"/(app)/contact": [~13,[2],[3]],
		"/(app)/[page]": [~6,[2],[3]]
	};

export const hooks = {
	handleError: (({ kind, error }) => { if (kind === 'unknown') { console.error(error); } }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));
export const encoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.encode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export const get_error_template = () => import('../shared/error-template.js').then(m => m.default);