
import error from './shared/error-template.js';

export const options = {
	app_template_contains_nonce: false,
	csp: {"mode":"auto","directives":{"upgrade-insecure-requests":false,"block-all-mixed-content":false},"reportOnly":{"upgrade-insecure-requests":false,"block-all-mixed-content":false}},
	csrf_trusted_origins: [],
	service_worker_options: null,
	templates: {
		app: ({ head, body, assets, nonce, env }) => "<!doctype html>\n<html lang=\"vi\">\n  <head>\n    <meta charset=\"utf-8\" />\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n    <meta name=\"text-scale\" content=\"scale\" />\n    <meta name=\"theme-color\" content=\"#0052FF\" />\n    <meta name=\"referrer\" content=\"strict-origin-when-cross-origin\" />\n\n    <link rel=\"manifest\" href=\"/manifest.json\" />\n    <link rel=\"icon\" href=\"/favicon.svg\" type=\"image/svg+xml\" />\n    <link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />\n\n    <meta name=\"mobile-web-app-capable\" content=\"yes\" />\n    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />\n    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black-translucent\" />\n\n    <!-- Theme: must run before first paint -->\n    <script>\n      ;(() => {\n        const saved = localStorage.getItem('theme-preference')\n        const dark =\n          saved === 'dark' ||\n          (saved !== 'light' && window.matchMedia('(prefers-color-scheme: dark)').matches)\n\n        document.documentElement.classList.toggle('dark', dark)\n      })()\n    </script>\n    %unocss-svelte-scoped.global% " + head + "\n  </head>\n\n  <body\n    data-sveltekit-preload-data=\"hover\"\n    data-sveltekit-preload-code=\"hover\"\n    class=\"bg-white dark:bg-gray-950\"\n  >\n    <div style=\"display: contents\">" + body + "</div>\n  </body>\n</html>\n",
		error
	}
};

export async function get_hooks() {
	let handle;
	let handleFetch;
	let handleError;
	let init;
	

	let reroute;
	let transport;
	

	return {
		handle,
		handleFetch,
		handleError,
		init,
		reroute,
		transport
	};
}
