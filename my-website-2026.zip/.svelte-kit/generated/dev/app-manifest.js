// empty during dev
export const immutable = [];
export const prerendered = [];

export const assets = [
	{"path":"ads.txt"},
	{"path":"apple-touch-icon.png"},
	{"path":"background.jpg"},
	{"path":"background.svg"},
	{"path":"favicon.svg"},
	{"path":"logo.svg"},
	{"path":"manifest.json"},
	{"path":"maskable-512x512.png"},
	{"path":"og-image.jpg"},
	{"path":"pwa-192x192.png"},
	{"path":"pwa-512x512.png"},
	{"path":"robots.txt"}
];

export const routes = [
	{"id":"/(app)","page":true,"endpoint":false},
	{"id":"/admin","page":true,"endpoint":false},
	{"id":"/(app)/blog","page":true,"endpoint":false},
	{"id":"/(app)/blog/category","page":true,"endpoint":false},
	{"id":"/(app)/blog/category/[category]","page":true,"endpoint":false},
	{"id":"/(app)/blog/tag","page":true,"endpoint":false},
	{"id":"/(app)/blog/tag/[tag]","page":true,"endpoint":false},
	{"id":"/(app)/blog/[post]","page":true,"endpoint":false},
	{"id":"/(app)/contact","page":true,"endpoint":false},
	{"id":"/(app)/rss.xml","page":false,"endpoint":true},
	{"id":"/(app)/sitemap.xml","page":false,"endpoint":true},
	{"id":"/(app)/[page]","page":true,"endpoint":false}
];